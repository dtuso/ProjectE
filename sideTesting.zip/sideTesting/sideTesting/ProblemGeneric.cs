﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace sideTesting
{
	class ProblemGeneric
	{
		public static void Solve()
		{

		}

	}

	class Problem097
	{

		//The first known prime found to exceed one million digits was discovered in 1999, and is a 
		//Mersenne  prime of the form 2^6972593−1; it contains exactly 2,098,960 digits. Subsequently 
		//other Mersenne primes, of the form 2^p−1, have been found which contain more digits.

		//However, in 2004 there was found a massive non-Mersenne prime which contains 2,357,207 digits: 
		//28433 × 2^7830457 + 1.

		//Find the last ten digits of this prime number.



		public static void Solve()
		{
			Console.WriteLine(BigInteger.MathPower(2,6972593)-1);
		}
	}

	class Problem058
	{

		//Starting with the num1 1 and moving to the right in a clockwise direction a 5 by 5 spiral is formed as follows:
		//
		//21 22 23 24 25
		//20  7  8  9 10
		//19  6  1  2 11
		//18  5  4  3 12
		//17 16 15 14 13
		//
		//It can be verified that the sum of both diagonals is 101.
		//
		//What is the sum of both diagonals in a 1001 by 1001 spiral formed in the same way?

		//Answer
		//26241

		static Dictionary<int, int> cntPrimesForSpiralSize = new Dictionary<int, int>();
		public static void Solve()
		{
			Stopwatch sw = new Stopwatch();
			sw.Start();
			bool greaterThan10 = true;
			for (int spiralSize = 3; greaterThan10; spiralSize += 2)
			{
				double ratio = ComputeCrossRatioOfPrimes(spiralSize);
				Console.WriteLine("S{0,2} x {0,2}  ratio = {1:P}", spiralSize, ratio);
				greaterThan10 = (ratio > 0.1);
			}

			sw.Stop();
			//Console.WriteLine("Spiral Size {0,2}x{0,2} \t found in {2}", spiralSize, sw.Elapsed);
		}

		private static double ComputeCrossRatioOfPrimes(int spiralSize)
		{
			return CountPrimes( spiralSize) / (double)(2*spiralSize-1);
		}

		static int CountPrimes(int spiralSize)
		{
			if (cntPrimesForSpiralSize.ContainsKey(spiralSize))
				return cntPrimesForSpiralSize[spiralSize];
			int numPrimes = 0;
			if ((spiralSize) != 3)
			{
				if (cntPrimesForSpiralSize.ContainsKey(spiralSize - 2))
					numPrimes = cntPrimesForSpiralSize[spiralSize - 2];
			}
			double square = (double)spiralSize * (double)spiralSize;// highest corner piece
			numPrimes += IsPrime(square) ? 1 : 0;

			square -= (spiralSize - 1);// next highest
			numPrimes += IsPrime(square) ? 1 : 0;

			square -= (spiralSize - 1);// next highest
			numPrimes += IsPrime(square) ? 1 : 0;

			square -= (spiralSize - 1);// lowest
			numPrimes += IsPrime(square) ? 1 : 0;

			cntPrimesForSpiralSize.Add(spiralSize, numPrimes);

			return numPrimes;

		}

		public static bool IsPrime(double number)
		{
			if (number <= 1)
				return false;
			if (number <= 3)
				return true;

			double max = Math.Sqrt(number);

			for (double den = 2; den <= max; den++)
			{
				if ((number % den) == 0)
				{
					return false;
				}
			}
			return true;

		}

		public static bool IsPrime(BigInteger number)
		{
			if (number <= 1)
				return false;
			if (number <= 3)
				return true;

			BigInteger max = number / 2; //Math.Sqrt(number);
			for (BigInteger den = 2; den <= max; den++)
			{
				if (BigInteger.Remainder(number, den) == 0)
				{
					return false;
				}
			}
			return true;

		}

		public static bool IsInteger(double num)
		{
			return (num == (int)num);
		}
	}



	class Problem063
	{

		// The 5-digit number, 16807=7^5, is also a fifth power. Similarly, 
		// the 9-digit number, 134217728=8^9, is a ninth power.

		// How many n-digit positive integers exist which are also an nth power?


		//Starting at 3/5/2008 5:44:48 PM
		//For Lenght of 1 the count is 9
		//For Lenght of 2 the count is 6
		//For Lenght of 3 the count is 5
		//For Lenght of 4 the count is 4
		//For Lenght of 5 the count is 3
		//For Lenght of 6 the count is 3
		//For Lenght of 7 the count is 2
		//For Lenght of 8 the count is 2
		//For Lenght of 9 the count is 2
		//For Lenght of 10 the count is 2
		//For Lenght of 11 the count is 1
		//For Lenght of 12 the count is 1
		//For Lenght of 13 the count is 1
		//For Lenght of 14 the count is 1
		//For Lenght of 15 the count is 1
		//For Lenght of 16 the count is 1
		//For Lenght of 17 the count is 1
		//For Lenght of 18 the count is 1
		//For Lenght of 19 the count is 1
		//For Lenght of 20 the count is 1
		//For Lenght of 21 the count is 1
		//For Lenght of 22 the count is 0
		//Total Count: 49
		//End of main (00:00:00.0160328) 3/5/2008 5:44:48 PM



		public static void Solve()
		{
			int count = 0;

			//for (int n = 1; ; n++)
			//{
			//    for (int d = 1; ;d++ )
			//    {
			//        BigInteger nthPower = BigInteger.MathPower(d, n);
			//        if (nthPower.LengthNum > n)
			//        {
			//            break;
			//        }
			//        if (nthPower.LengthNum == n && nthPower = )
			//        {
			//            count++;
			//            Console.WriteLine("{0,4}:{1}^{2}", count, d, n);
			//        }					
			//    }
			//}

			// special!!!
			bool go = true;
			for (int len = 1; go; len++)
			{
				int thisCount = 0;
				for (int i = 1; i < 10; i++)
				{
					//Console.WriteLine(BigInteger.MathPower(i, len));
					if (BigInteger.MathPower(i, len).LengthNum == len)
					{
						thisCount++;
					}
				}
				count += thisCount;
				go = (thisCount > 0);
				//Console.WriteLine("this count: {0}", thisCount);
				Console.WriteLine("For Lenght of {0} the count is {1}", len, thisCount);
			}
			//for (BigInteger num = 1; ; num++)
			//{

			//    int n = num.LengthNum;
			//    for (int i = 1; i < 10; i++)
			//    {
			//        BigInteger nthPower = BigInteger.MathPower(i, n);
			//        if (nthPower == num)
			//        {
			//            count++;
			//            Console.WriteLine("{0,5}:{1}^{2,2} = {3}", count, i, n, num);
			//            break;
			//        }
			//    }
			//}

			Console.WriteLine("Total Count: {0}",  count);

		}


		static int CountDigits(int num)
		{
			return num.ToString().Length;
		}


	}
	class Problem049
	{

		//The arithmetic sequence, 1487, 4817, 8147, in which each of the terms increases by 3330, 
		//is unusual in two ways: (i) each of the three terms are prime, and, (ii) each of the 4-digit 
		//numbers are permutations of one another.

		//There are no arithmetic sequences made up of three 1-, 2-, or 3-digit primes, exhibiting 
		//this property, but there is one other 4-digit increasing sequence.

		//What 12-digit number do you form by concatenating the three terms in this sequence?


		//Starting at 3/5/2008 4:45:18 PM
		//148748178147
		//296962999629
		//done.
		//End of main (00:00:03.2331665) 3/5/2008 4:45:22 PM

		public static void Solve()
		{
			// Problem049
			int primeBase = 999;

			while (primeBase<=9999)
			{
				GetNextPrime(ref primeBase);
				for (int step = 2; step < 3333; step++)
				{
					if (IsPrime(primeBase + step) && IsPrime(primeBase + step + step))
					{
						//check to see if contains same digits
						string baseStr = GetCountDigits(primeBase);
						string nextStr = GetCountDigits(primeBase + step );
						string lastStr = GetCountDigits(primeBase + step + step);
						if (baseStr == nextStr && baseStr == lastStr)
						{
							Console.WriteLine("{0}{1}{2}", primeBase, primeBase + step, primeBase + step+step);
						}
					}
				}

			}

			Console.WriteLine("done.");

		}


		static string GetCountDigits(int num)
		{
			StringBuilder sb = new StringBuilder();
			string strNum = num.ToString();
			int[] digitCount = new int[10];

			for (int i = 0; i < strNum.Length; i++)
			{
				digitCount[Int32.Parse(strNum[i].ToString())]++;
			}
			for (int i = 0; i < 10; i++)
			{
				sb.AppendFormat("{0,2}", digitCount[i]);
			}

			return sb.ToString();
		}


		public static bool IsPrime(int number)
		{
			number = Math.Abs(number);
			if (number <= 1)
				return false;
			if (number <= 3)
				return true;
			double max = Math.Sqrt(number);
			for (double den = 2; den <= max; den++)
			{
				if (IsInteger(number / den))
				{
					return false;
				}
			}
			return true;

		}

		public static bool IsInteger(double num)
		{
			return (num == (int)num);
		}

		public static void GetNextPrime(ref int number)
		{
			do { } while (!IsPrime(++number));
		}


	}

	class Problem047
	{
		//The first two consecutive numbers to have two distinct prime factors are:

		//14 = 2 × 7
		//15 = 3 × 5

		//The first three consecutive numbers to have three distinct prime factors are:

		//644 = 2² × 7 × 23
		//645 = 3 × 5 × 43
		//646 = 2 × 17 × 19.

		//Find the first four consecutive integers to have four distinct primes factors. 
		//What is the first of these numbers?


		//Starting at 3/5/2008 4:28:25 PM
		//134043
		//End of main (00:00:01.3128267) 3/5/2008 4:28:26 PM


		public static void Solve()
		{
			// Problem047
			int numConsecutive = 4;
			
			for (int n = 1;; n++)
			{
				bool found = true;
				for (int cons = 0; cons < numConsecutive; cons++)
				{
					found = found && (GetCountDistinctPrimeDivisors(n + cons) == numConsecutive);

				}

				if (found)
				{

					Console.WriteLine(n);
					//for (int cons = 0; cons < numConsecutive; cons++)
					//{
					//    Console.WriteLine(GetCountDistinctPrimeDivisors(n + cons) );
					//}
					break;
				}
			}
		}

		public static bool IsPrime(int number)
		{
			number = Math.Abs(number);
			if (number <= 1)
				return false;
			if (number <= 3)
				return true;
			double max = Math.Sqrt(number);
			for (double den = 2; den <= max; den++)
			{
				if (IsInteger(number / den))
				{
					return false;
				}
			}
			return true;

		}

		public static void GetNextPrime(ref int number)
		{
			do { } while (!IsPrime(++number));
		}

		public static int GetCountDistinctPrimeDivisors(int number)
		{
			List<int> divs = GetProperDivisors(number);
			List<int> primes = new List<int>();
			foreach(int div in divs)
			{
				if (IsPrime(div) && !primes.Contains(div))
					primes.Add(number);
			}
			return primes.Count;
		}

		public static List<int> GetProperDivisors(int number)
		{
			List<int> divs = new List<int>();
			divs.Add(1);

			double sqrRtNum = Math.Sqrt(number);
			for (int d = 2; d < sqrRtNum; d++)
			{
				if (number % d == 0)
				{
					divs.Add(d);
					divs.Add(number/d);
				}
			}
			if (IsInteger(sqrRtNum))
			{
				divs.Add((int)sqrRtNum);
			}
			return divs;
		}

		public static bool IsInteger(double num)
		{
			return (num == (int)num);
		}

	}


	class Problem046
	{


		//It was proposed by Christian Goldbach that every odd composite number can be written as the sum of 
		//a prime and twice a square.

		//9 = 7 + 2×1^2
		//15 = 7 + 2×2^2
		//21 = 3 + 2×3^2
		//25 = 7 + 2×3^2
		//27 = 19 + 2×2^2
		//33 = 31 + 2×1^2

		//It turns out that the conjecture was false.

		//What is the smallest odd composite that cannot be written as the sum of a prime and twice a square?

		//Starting at 3/5/2008 3:59:01 PM
		//5777
		//done 5777:
		//End of main (00:00:02.7451944) 3/5/2008 3:59:04 PM



		public static void Solve()
		{
			// Problem046
			int minOddCompositeNotASum = Int32.MaxValue;
			bool foundOneThatsNotASum = false;
			int composite = -1;
			while (!foundOneThatsNotASum)
			{
				GetNextComposite(ref composite);
				if (composite % 2 == 0) continue;
				int prime = -1;
				bool foundASum = false;
				while (prime < composite)
				{
					GetNextPrime(ref prime);
					for (int n = 1; n <= Math.Sqrt(composite-prime); n++)
					{
						int res = prime + 2 * n * n;
						if (res == composite)
						{
							foundASum = true;
							break;
						}
					}
				}
				if (!foundASum && composite < minOddCompositeNotASum)
				{
					foundOneThatsNotASum = true;
					minOddCompositeNotASum = composite;
					Console.WriteLine(composite);
				}
			}
			Console.WriteLine("done {0}: " , minOddCompositeNotASum);
		}
		
		public static bool IsPrime(int number)
		{
			number = Math.Abs(number);
			if (number <= 1)
				return false;
			if (number <= 3)
				return true;
			double max = Math.Sqrt(number);
			for (double den = 2; den <= max; den++)
			{
				if (IsInteger(number / den))
				{
					return false;
				}
			}
			return true;

		}

		public static void GetNextPrime(ref int number)
		{
			do { } while (!IsPrime(++number));
		}


		public static bool IsComposite(int num)
		{
			if (num < 2) return false;
			return !IsPrime(num);
		}

		public static void GetNextComposite(ref int number)
		{
			do { } while (!IsComposite(++number));
		}

		public static bool IsInteger(double num)
		{
			return (num == (int)num);
		}

	}


	class Problem059
	{

		//Each character on a computer is assigned a unique code and the preferred standard is ASCII 
		//(American Standard Code for Information Interchange). For example, uppercase A = 65, asterisk 
		//(*) = 42, and lowercase k = 107.

		//A modern encryption method is to take a text file, convert the bytes to ASCII, then XOR each 
		//byte with a given value, taken from a secret key. The advantage with the XOR function is that 
		//using the same encryption key on the cipher text, restores the plain text; 
		//for example, 65 XOR 42 = 107, then 107 XOR 42 = 65.

		//For unbreakable encryption, the key is the same length as the plain text message, and the key 
		//is made up of random bytes. The user would keep the encrypted message and the encryption key 
		//in different locations, and without both "halves", it is impossible to decrypt the message.

		//Unfortunately, this method is impractical for most users, so the modified method is to use a 
		//password as a key. If the password is shorter than the message, which is likely, the key is 
		//repeated cyclically throughout the message. The balance for this method is using a sufficiently 
		//long password key for security, but short enough to be memorable.

		//Your task has been made easy, as the encryption key consists of three lower case characters. 
		//Using cipher1.txt (right click and 'Save Link/Target As...'), a file containing the encrypted 
		//ASCII codes, and the knowledge that the plain text must contain common English words, decrypt 
		//the message and find the sum of the ASCII values in the original text.


		private static int[] encrypted = new int[] { 79, 59, 12, 2, 79, 35, 8, 28, 20, 2, 3, 68, 8, 9, 68, 45, 0, 12, 9, 67, 68, 4, 7, 5, 23, 27, 1, 21, 79, 85, 78, 79, 85, 71, 38, 10, 71, 27, 12, 2, 79, 6, 2, 8, 13, 9, 1, 13, 9, 8, 68, 19, 7, 1, 71, 56, 11, 21, 11, 68, 6, 3, 22, 2, 14, 0, 30, 79, 1, 31, 6, 23, 19, 10, 0, 73, 79, 44, 2, 79, 19, 6, 28, 68, 16, 6, 16, 15, 79, 35, 8, 11, 72, 71, 14, 10, 3, 79, 12, 2, 79, 19, 6, 28, 68, 32, 0, 0, 73, 79, 86, 71, 39, 1, 71, 24, 5, 20, 79, 13, 9, 79, 16, 15, 10, 68, 5, 10, 3, 14, 1, 10, 14, 1, 3, 71, 24, 13, 19, 7, 68, 32, 0, 0, 73, 79, 87, 71, 39, 1, 71, 12, 22, 2, 14, 16, 2, 11, 68, 2, 25, 1, 21, 22, 16, 15, 6, 10, 0, 79, 16, 15, 10, 22, 2, 79, 13, 20, 65, 68, 41, 0, 16, 15, 6, 10, 0, 79, 1, 31, 6, 23, 19, 28, 68, 19, 7, 5, 19, 79, 12, 2, 79, 0, 14, 11, 10, 64, 27, 68, 10, 14, 15, 2, 65, 68, 83, 79, 40, 14, 9, 1, 71, 6, 16, 20, 10, 8, 1, 79, 19, 6, 28, 68, 14, 1, 68, 15, 6, 9, 75, 79, 5, 9, 11, 68, 19, 7, 13, 20, 79, 8, 14, 9, 1, 71, 8, 13, 17, 10, 23, 71, 3, 13, 0, 7, 16, 71, 27, 11, 71, 10, 18, 2, 29, 29, 8, 1, 1, 73, 79, 81, 71, 59, 12, 2, 79, 8, 14, 8, 12, 19, 79, 23, 15, 6, 10, 2, 28, 68, 19, 7, 22, 8, 26, 3, 15, 79, 16, 15, 10, 68, 3, 14, 22, 12, 1, 1, 20, 28, 72, 71, 14, 10, 3, 79, 16, 15, 10, 68, 3, 14, 22, 12, 1, 1, 20, 28, 68, 4, 14, 10, 71, 1, 1, 17, 10, 22, 71, 10, 28, 19, 6, 10, 0, 26, 13, 20, 7, 68, 14, 27, 74, 71, 89, 68, 32, 0, 0, 71, 28, 1, 9, 27, 68, 45, 0, 12, 9, 79, 16, 15, 10, 68, 37, 14, 20, 19, 6, 23, 19, 79, 83, 71, 27, 11, 71, 27, 1, 11, 3, 68, 2, 25, 1, 21, 22, 11, 9, 10, 68, 6, 13, 11, 18, 27, 68, 19, 7, 1, 71, 3, 13, 0, 7, 16, 71, 28, 11, 71, 27, 12, 6, 27, 68, 2, 25, 1, 21, 22, 11, 9, 10, 68, 10, 6, 3, 15, 27, 68, 5, 10, 8, 14, 10, 18, 2, 79, 6, 2, 12, 5, 18, 28, 1, 71, 0, 2, 71, 7, 13, 20, 79, 16, 2, 28, 16, 14, 2, 11, 9, 22, 74, 71, 87, 68, 45, 0, 12, 9, 79, 12, 14, 2, 23, 2, 3, 2, 71, 24, 5, 20, 79, 10, 8, 27, 68, 19, 7, 1, 71, 3, 13, 0, 7, 16, 92, 79, 12, 2, 79, 19, 6, 28, 68, 8, 1, 8, 30, 79, 5, 71, 24, 13, 19, 1, 1, 20, 28, 68, 19, 0, 68, 19, 7, 1, 71, 3, 13, 0, 7, 16, 73, 79, 93, 71, 59, 12, 2, 79, 11, 9, 10, 68, 16, 7, 11, 71, 6, 23, 71, 27, 12, 2, 79, 16, 21, 26, 1, 71, 3, 13, 0, 7, 16, 75, 79, 19, 15, 0, 68, 0, 6, 18, 2, 28, 68, 11, 6, 3, 15, 27, 68, 19, 0, 68, 2, 25, 1, 21, 22, 11, 9, 10, 72, 71, 24, 5, 20, 79, 3, 8, 6, 10, 0, 79, 16, 8, 79, 7, 8, 2, 1, 71, 6, 10, 19, 0, 68, 19, 7, 1, 71, 24, 11, 21, 3, 0, 73, 79, 85, 87, 79, 38, 18, 27, 68, 6, 3, 16, 15, 0, 17, 0, 7, 68, 19, 7, 1, 71, 24, 11, 21, 3, 0, 71, 24, 5, 20, 79, 9, 6, 11, 1, 71, 27, 12, 21, 0, 17, 0, 7, 68, 15, 6, 9, 75, 79, 16, 15, 10, 68, 16, 0, 22, 11, 11, 68, 3, 6, 0, 9, 72, 16, 71, 29, 1, 4, 0, 3, 9, 6, 30, 2, 79, 12, 14, 2, 68, 16, 7, 1, 9, 79, 12, 2, 79, 7, 6, 2, 1, 73, 79, 85, 86, 79, 33, 17, 10, 10, 71, 6, 10, 71, 7, 13, 20, 79, 11, 16, 1, 68, 11, 14, 10, 3, 79, 5, 9, 11, 68, 6, 2, 11, 9, 8, 68, 15, 6, 23, 71, 0, 19, 9, 79, 20, 2, 0, 20, 11, 10, 72, 71, 7, 1, 71, 24, 5, 20, 79, 10, 8, 27, 68, 6, 12, 7, 2, 31, 16, 2, 11, 74, 71, 94, 86, 71, 45, 17, 19, 79, 16, 8, 79, 5, 11, 3, 68, 16, 7, 11, 71, 13, 1, 11, 6, 1, 17, 10, 0, 71, 7, 13, 10, 79, 5, 9, 11, 68, 6, 12, 7, 2, 31, 16, 2, 11, 68, 15, 6, 9, 75, 79, 12, 2, 79, 3, 6, 25, 1, 71, 27, 12, 2, 79, 22, 14, 8, 12, 19, 79, 16, 8, 79, 6, 2, 12, 11, 10, 10, 68, 4, 7, 13, 11, 11, 22, 2, 1, 68, 8, 9, 68, 32, 0, 0, 73, 79, 85, 84, 79, 48, 15, 10, 29, 71, 14, 22, 2, 79, 22, 2, 13, 11, 21, 1, 69, 71, 59, 12, 14, 28, 68, 14, 28, 68, 9, 0, 16, 71, 14, 68, 23, 7, 29, 20, 6, 7, 6, 3, 68, 5, 6, 22, 19, 7, 68, 21, 10, 23, 18, 3, 16, 14, 1, 3, 71, 9, 22, 8, 2, 68, 15, 26, 9, 6, 1, 68, 23, 14, 23, 20, 6, 11, 9, 79, 11, 21, 79, 20, 11, 14, 10, 75, 79, 16, 15, 6, 23, 71, 29, 1, 5, 6, 22, 19, 7, 68, 4, 0, 9, 2, 28, 68, 1, 29, 11, 10, 79, 35, 8, 11, 74, 86, 91, 68, 52, 0, 68, 19, 7, 1, 71, 56, 11, 21, 11, 68, 5, 10, 7, 6, 2, 1, 71, 7, 17, 10, 14, 10, 71, 14, 10, 3, 79, 8, 14, 25, 1, 3, 79, 12, 2, 29, 1, 71, 0, 10, 71, 10, 5, 21, 27, 12, 71, 14, 9, 8, 1, 3, 71, 26, 23, 73, 79, 44, 2, 79, 19, 6, 28, 68, 1, 26, 8, 11, 79, 11, 1, 79, 17, 9, 9, 5, 14, 3, 13, 9, 8, 68, 11, 0, 18, 2, 79, 5, 9, 11, 68, 1, 14, 13, 19, 7, 2, 18, 3, 10, 2, 28, 23, 73, 79, 37, 9, 11, 68, 16, 10, 68, 15, 14, 18, 2, 79, 23, 2, 10, 10, 71, 7, 13, 20, 79, 3, 11, 0, 22, 30, 67, 68, 19, 7, 1, 71, 8, 8, 8, 29, 29, 71, 0, 2, 71, 27, 12, 2, 79, 11, 9, 3, 29, 71, 60, 11, 9, 79, 11, 1, 79, 16, 15, 10, 68, 33, 14, 16, 15, 10, 22, 73 };
		private static int[] solved = new int[encrypted.Length];
		public static void Solve()
		{
			bool found = false;

			for (int a = 97; a < 97 + 26; a++)
			{
				for (int b = 97; b < 97 + 26; b++)
				{
					for (int c = 97; c < 97 + 26; c++)
					{
						DecryptFile(new int[] { a, b, c });
						if (FileContains(" and ") && FileContains(" the ") )
						{
							Console.WriteLine("Found at {0}{1}{2} for {3} ", Char.ConvertFromUtf32(a), Char.ConvertFromUtf32(b), Char.ConvertFromUtf32(c), SumSolved());
							Console.WriteLine(SolvedToString());
						}
					}
				}
			}

		}

		static void DecryptFile(int[] keyToTry)
		{
			int keyIdx = 0;
			for (int i = 0; i < encrypted.Length; i++)
			{
				solved[i] = endecrypt(encrypted[i], keyToTry[keyIdx]);
				keyIdx = (++keyIdx) % keyToTry.Length;
				//Console.Write(Char.ConvertFromUtf32(solved[i]));
			}
			//Console.WriteLine();
		}

		static string SolvedToString()
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < solved.Length; i++)
			{
				sb.Append(Char.ConvertFromUtf32(solved[i]));
			}
			return sb.ToString();
		}

		static int SumSolved()
		{
			int sum = 0;

			for (int i = 0; i < solved.Length; i++)
			{
				sum += solved[i];
			}
			return sum;
		}

		static bool FileContains(string word)
		{
			string text = SolvedToString();
			return (text.IndexOf(word) > -1);
		}

		static int[] ToAscii(string word)
		{
			int[] asc = new int[word.Length];
			for (int i = 0; i < word.Length; i++)
			{
				asc[i] = word[i]; // same as: asc[i] = Char.ConvertToUtf32(word,i)
				Console.Write(asc[i]);
			}
			Console.WriteLine();
			return asc;
		}

		static int endecrypt(int value, int key)
		{
			return (value ^ key);
		}

	}
	class Problem052
	{

		// It can be seen that the number, 125874, and its double, 251748, contain exactly the same digits, 
		// but in a different order.

		// Find the smallest positive integer, x, such that 2x, 3x, 4x, 5x, and 6x, contain the same digits.


		//Starting at 3/5/2008 1:36:15 PM
		//142857 =  0 1 1 0 1 1 0 1 1 0
		//End of main (00:00:01.5236128) 3/5/2008 1:36:17 PM


		public static void Solve()
		{
			bool found = false;

			for (int i = 1; !found; i++)
			{
				string thisI = GetCountDigits(i);

				if (GetCountDigits(i * 2) == thisI &&
					GetCountDigits(i * 3) == thisI &&
					GetCountDigits(i * 4) == thisI &&
					GetCountDigits(i * 5) == thisI &&
					GetCountDigits(i * 6) == thisI)
				{
					Console.WriteLine("{0} = {1}" ,i, thisI);
					found = true;
					break;
				}
			}

		}

		static string GetCountDigits(int num)
		{
			StringBuilder sb = new StringBuilder();
			string strNum = num.ToString();
			int[] digitCount = new int[10];

			for (int i = 0; i < strNum.Length; i++)
			{
				digitCount[ Int32.Parse(strNum[i].ToString())]++;
			}
			for (int i = 0; i < 10; i++)
			{
				sb.AppendFormat("{0,2}", digitCount[i]);
			}

			return sb.ToString();
		}

	}
}
