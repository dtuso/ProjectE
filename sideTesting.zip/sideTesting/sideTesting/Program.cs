using System;
using System.Diagnostics;

namespace sideTesting
{
    class Program
    {
        static void Main(string[] args)
        {

			
			Stopwatch sw = new Stopwatch();

            Console.WriteLine("Starting at {0}", DateTime.Now);

			sw.Start();

			Triangle t = new Triangle(new System.Drawing.Point(0, 0), new System.Drawing.Point(0, 4), new System.Drawing.Point(3, 0));


			//Problem182.Solve();
			
            //int maxIterations = 100;
            //int lastLen = 0;
            //BigInt lastFactorial = BigInt.Zero();
            //BigInt thisFactorial = BigInt.One();
            //int outer = 1;
            //while (lastLen<1000)
            ////for (int outer = 1; outer < maxIterations; outer++)
            //{
            //    outer++;
            //    thisFactorial = GetNextFactorial(thisFactorial, ref lastFactorial);
            //    if (thisFactorial.Length > lastLen)
            //    {
            //        lastLen = thisFactorial.Length;
            //        Console.WriteLine("F{0}={1} \t\t {2} long", outer, thisFactorial, lastLen);
            //    }
            //}

            Console.WriteLine(  "End of main ({0}) {1}" , sw.Elapsed, DateTime.Now);
            Console.ReadLine();

        }

		static void DoPal(string pal)
		{

			Console.WriteLine("{0} is {1}", pal, CheckPalindrome.isPalindrome(pal));
		}

    	static BigInt GetNextFactorial(BigInt thisFactorial, ref BigInt lastFactorial)
        {
            BigInt tmp = thisFactorial;
            BigInt result = thisFactorial + lastFactorial;
            lastFactorial = tmp;
            return result;
        }
    }
}
