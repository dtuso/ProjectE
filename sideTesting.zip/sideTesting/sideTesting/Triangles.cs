﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;


namespace sideTesting
{

	public class Triangle
	{
		private Point _pointA;
		private Point _pointB;
		private Point _pointC;
		private Line _lineAB;
		private Line _lineAC;
		private Line _lineBC;
		private bool _containsOrigin = false;
		private double _angleAtA; //CAAB
		private double _angleAtB; //ABBC
		private double _angleAtC; //ACCB


		public Point PointA
		{
			get { return _pointA; }
		}

		public Point PointB
		{
			get { return _pointB; }
		}

		public Point PointC
		{
			get { return _pointC; }
		}

		public Line AB
		{
			get { return _lineAB; }
		}

		public Line AC
		{
			get { return _lineAC; }
		}

		public Line BC
		{
			get { return _lineBC; }
		}

		public bool ContainsOrigin
		{
			get { return _containsOrigin; }
		}

		public Triangle(Point A, Point B, Point C)
		{
			_pointA = A;
			_pointB = B;
			_pointC = C;
			_lineAB = new Line(A, B);
			_lineAC = new Line(A, C);
			_lineBC = new Line(B, C);
			CalculateAngles();
			DetermineIfContainsOrigin();
		}


		private void CalculateAngles()
		{
			//http://answers.google.com/answers/threadview?id=38131
			
			//A := arccos((b^2 + c^2 - a^2)/2bc) 
			//B := arccos((a^2 + c^2 - b^2)/2ac) 
			//C := arccos((a^2 + b^2 - c^2)/2ab) 

			double a = BC.Length;
			double a2 = Math.Pow(a,2);

			double b = AC.Length;
			double b2 = Math.Pow(b,2);

			double c = AB.Length;
			double c2 = Math.Pow(c,2);

			_angleAtA = Math.Acos((b2 + c2 - a2) / (2 * b * c));
			_angleAtB = Math.Acos((a2 + c2 - b2) / (2 * a * c));
			_angleAtC = Math.Acos((a2 + b2 - c2) / (2 * a * b));

		}

		private void DetermineIfContainsOrigin()
		{
			// check the smallest angle between AB and AC





		}





	}

}
