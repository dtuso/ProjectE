using System;
using System.Collections.Generic;
using System.Text;

namespace sideTesting
{
	class Problem179
	{
		//Find the number of integers 1 < n < 107, for which n and n + 1 have the same number of positive divisors. 
		// For example, 14 has the positive divisors 1, 2, 7, 14 while 15 has 1, 3, 5, 15.



		// SOLUTION
		//Starting at 2/27/2008 11:51:22 AM
		//986262
		//Done! 2/27/2008 11:55:36 AM


		public static void Solve()
		{
			int cntMatches = 0;
			int cntForI;
			int cntForIPlusOne = countDivisors(2); ;
			for (int i = 2; i < 10000000; i++)
			{
				cntForI = cntForIPlusOne;
				cntForIPlusOne = countDivisors(i + 1);

				if (cntForI == cntForIPlusOne)
				{
					cntMatches++;
					//Console.WriteLine("Found # {0} is: {1} and {2} which both have {3}", cntMatches, outer, outer + 1, cntForI);
				}
			}
			Console.WriteLine("{0}", cntMatches);
		}

		private static int countDivisors(int num)
		{
			int cnt = 2; //include 1 and (num)
			double sqrRtNum = Math.Sqrt((double)num);
			if ((sqrRtNum == (int)sqrRtNum)) cnt++; // count one more when the sqrt is a whole number
			for (int d = 2; d < sqrRtNum; d++)
			{
				if (num % d == 0)
				{
					cnt+=2;
				}

			}
			return cnt;
		}


	}
}
