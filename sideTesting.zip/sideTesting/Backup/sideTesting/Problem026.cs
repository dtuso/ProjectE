using System;
using System.Text.RegularExpressions;

namespace sideTesting
{
    class Problem026
	{
		private static Regex r = new Regex(@"(?<char>[0-9]+)\k<char>");
        /// <summary>
        /// A unit fraction contains 1 in the numerator. The decimal representation of the unit 
        /// fractions with denominators 2 to 10 are given:1/2	= 	0.5
        /// 1/3	= 	0.(3)
        /// 1/4	= 	0.25
        /// 1/5	= 	0.2
        /// 1/6	= 	0.1(6)
        /// 1/7	= 	0.(142857)
        /// 1/8	= 	0.125
        /// 1/9	= 	0.(1)
        /// 1/10	= 	0.1
        /// Where 0.1(6) means 0.166666..., and has a 1-digit recurring cycle. 
        /// It can be seen that 1/7 has a 6-digit recurring cycle.
        /// Find the value of d < 1000 for which 1/d contains the longest recurring 
        /// cycle in its decimal fraction part.
        /// </summary>
        public static void Solve()
        {
			
            int max = 10000;
            int longestLength = 0;
            int valueOfLongest = 0;
            int thisLength = 0;
            for (int d = 3; d <= max; d++)
            {
                thisLength = LengthRepitions(d);
                if (thisLength > longestLength)
                {
                    longestLength = thisLength;
                    valueOfLongest = d;
                }
            }

            Console.WriteLine("LONGESTS {0} has a length of {1}", valueOfLongest, longestLength);
        }

        public static int LengthRepitions(int denominator)
        {


			decimal precision = Decimal.Parse("10000000000000000000000000000");
			decimal fraction = (decimal)precision / Decimal.Parse(denominator.ToString());
            string remainer = fraction.ToString().Replace(".",String.Empty);

			int length = FindLengthRepeatingSequences(remainer, true);
			// if found repeating sequence, then check the sequence for any repeats.
			// make it call itself recursively so we can find the real "shortest" length of repeating characters.

			Console.WriteLine("length = {0,2} for 1/{1} = {2}", length, denominator, "0." + remainer);
            
			return length;
        }


		private static int FindLengthRepeatingSequences( string item, bool firstTime)
		{
			int length = Int32.MaxValue;
			string shortestSeq = "";
			Match singleMatch = r.Match(item);
			if (singleMatch.Success)
			{
				foreach ( Group g in singleMatch.Groups )
				{
					if ( g.Length < length )
					{
						length = g.Length;
						shortestSeq = g.Value;
					}
				}
			}
			if (length == Int32.MaxValue || length == 0)
			{
				if (firstTime)
				{
					return 0;
				}
				else
				{
					return item.Length;
				}
			}
			
			return FindLengthRepeatingSequences(shortestSeq, false);
			

			

			return length;
		}

    	private static bool isRepetative(string seq, string whole)
        {
            bool result = true;
            for (int idx = 0; idx < whole.Length; idx += seq.Length)
            {
                if ((whole.Length - idx) < seq.Length)
                {
                    // example "142857142857" is in "1428571428571428571428571429" at idx of 24
                    break;
                }
                if (whole.Substring(idx, seq.Length) != seq)
                {
                    result=false;
                    break;
                }
            }
            return result;
        }
    }

}
