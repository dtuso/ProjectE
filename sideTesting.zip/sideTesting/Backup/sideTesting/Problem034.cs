using System;
using System.Diagnostics;

namespace sideTesting
{

	class Problem034
	{

		// 145 is a curious number, as 1! + 4! + 5! = 1 + 24 + 120 = 145.
		// Find the sum of all numbers which are equal to the sum of the factorial of their digits.
		// Note: as 1! = 1 and 2! = 2 are not sums they are not included.

		public static void Solve()
		{
			decimal sum = 0m;
			Stopwatch sw = new Stopwatch();

			sw.Start();
			decimal counter = 145;
			while (counter < Decimal.Parse("99,999,999"))
			{

				if (isFactorialSum(counter))
				{
					sum += counter;
					Console.WriteLine();
					Console.WriteLine("At {0} found: {1} to make a sum of {2}", sw.Elapsed, counter, sum);
				}

				if (counter % 20000000 == 0)
				{
					Console.WriteLine("At {0} now up to {1:N} with a sum of {2}", sw.Elapsed, counter, sum);
				}
				counter++;

			}

			sw.Stop();
			Console.WriteLine(sum);
		}

		private static bool isFactorialSum(decimal numToCheck)
		{
			char[] digits = numToCheck.ToString().ToCharArray();

			decimal sumOfFactorials = 0;
			foreach (char ch in digits)
			{
				sumOfFactorials += DigitFactorial(ch);
			}
			return (numToCheck == sumOfFactorials);
		}


		private static decimal DigitFactorial(char digit)
		{
			switch (digit)
			{
				case '1':
					{
						return 1m;
					}
				case '2':
					{
						return 2m;
					}
				case '3':
					{
						return 6m;
					}
				case '4':
					{
						return 24m;
					}
				case '5':
					{
						return 120m;
					}
				case '6':
					{
						return 720m;
					}
				case '7':
					{
						return 5040m;
					}
				case '8':
					{
						return 40320m;
					}
				case '9':
					{
						return 3628800m;
					}
				default:
					{
						return 0m;
					}
			}

		}
	}
}
