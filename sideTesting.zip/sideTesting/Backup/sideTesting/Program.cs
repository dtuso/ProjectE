using System;
using System.Collections.Generic;
using System.Text;

namespace sideTesting
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Starting at {0}", DateTime.Now);

            //for ( int i = 1; i <= 16; i++ )
            //{
            //    Problem015.Solve(i);
            //}

			Problem034.Solve();

            //int maxIterations = 100;
            //int lastLen = 0;
            //BigInt lastFactorial = BigInt.Zero();
            //BigInt thisFactorial = BigInt.One();
            //int i = 1;
            //while (lastLen<1000)
            ////for (int i = 1; i < maxIterations; i++)
            //{
            //    i++;
            //    thisFactorial = GetNextFactorial(thisFactorial, ref lastFactorial);
            //    if (thisFactorial.Length > lastLen)
            //    {
            //        lastLen = thisFactorial.Length;
            //        Console.WriteLine("F{0}={1} \t\t {2} long", i, thisFactorial, lastLen);
            //    }
            //}

            Console.WriteLine(  "Done! {0}" , DateTime.Now);
            Console.ReadLine();

        }

        static BigInt GetNextFactorial(BigInt thisFactorial, ref BigInt lastFactorial)
        {
            BigInt tmp = thisFactorial;
            BigInt result = thisFactorial + lastFactorial;
            lastFactorial = tmp;
            return result;
        }
    }
}
