using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace sideTesting
{

    //For 21x21 had 137846528820 in 02:36:17.6405505
    //Done! 2/18/2008 4:00:01 PM


    /// <summary>
    /// 
    /// </summary>
    class Problem015
    {
        static int maxNodeIdx;

        static Stopwatch sw = new Stopwatch();

        private static int[,] nodes;
        private static Int64 numPathsFound = 0;

        public static void Solve(int numSqaures)
        {
            sw.Start();
            maxNodeIdx = numSqaures;
            FindRoutes(0,0 );
            sw.Stop();

            Console.WriteLine("For {0,2}numToCheck{0,2} had {1,20:N0} in {2}", maxNodeIdx + 1, numPathsFound, sw.Elapsed);
            numPathsFound = 0;
        }

        
        private static void FindRoutes(int x, int y)
        {

            // check across
            if (x + 1 <= maxNodeIdx)
            {
                // we have a valid node to the right
                if (x + 1 == maxNodeIdx && y == maxNodeIdx)
                {
                    // we're at the end of this particular path!  
                    numPathsFound++;
                    //if (numPathsFound%10000000==0)
                    //    Console.WriteLine("{0:N0}", numPathsFound);

                }
                else
                {
                    FindRoutes(x + 1, y);
                }
            }

            if (y + 1 <= maxNodeIdx)
            {
                // we have a valid node down
                if (x == maxNodeIdx && y + 1 == maxNodeIdx)
                {
                    // we're at the end!  
                    numPathsFound++;
                    //if (numPathsFound % 10000000 == 0)
                    //    Console.WriteLine("{0:N0}", numPathsFound);
                }
                else
                {
                    FindRoutes(x, y + 1);
                }
            }

        }

    }
}
