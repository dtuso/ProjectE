using System;
using System.Diagnostics;
using ProjectEuler.Helpers;
using ProjectEuler.Problems;


namespace ProjectEuler
{
    class Program
    {

		static void Main(string[] args)
        {
			#region NotCompleted
			//  44, 50, 51, 54, 60, 61, 62, 64, 65, 66, 68-70, 72-80, 82-88, 90, 91, 93-97, 99-111, 113-123, 125-144, 146-178, 180-
			#endregion

            Console.WriteLine("Start of Main {0}", DateTime.Now);
            Stopwatch sw = new Stopwatch();
			sw.Start();

			Problem156.Solve();
			
            sw.Stop();

            Console.WriteLine("End of Main ({0}) {1}", sw.Elapsed, DateTime.Now);
            Console.ReadLine();
        }

    }
}

