using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectEuler.Helpers
{



	class BigInt
	{
		private char[] num;

		public int Length { get { return num.Length; } }

		public BigInt(string number)
		{
			num = number.ToCharArray();
		}

		private Stack<int> ToIntStack()
		{
			Stack<int> result = new Stack<int>();
			foreach (char c in num)
			{
				result.Push(Int32.Parse(c.ToString()));
			}
			return result;
		}

		public static BigInt Zero()
		{
			return new BigInt("0");
		}

		public static BigInt One()
		{
			return new BigInt("1");
		}

		public override string ToString()
		{
			StringBuilder s = new StringBuilder();
			foreach (char c in num)
			{
				s.Append(c);
			}
			return s.ToString();
		}

		public static BigInt operator +(BigInt b1, BigInt b2)
		{
			int maxLen = 1 + Math.Max(b1.num.Length, b2.num.Length);
			Stack<int> s1 = b1.ToIntStack();
			Stack<int> s2 = b2.ToIntStack();
			string n3 = "";
			int carryBit = 0;
			int d1 = 0;
			int d2 = 0;
			int d3 = 0;
			for (int i = 1; i <= maxLen; i++)
			{
				d1 = (s1.Count == 0) ? 0 : s1.Pop();
				d2 = (s2.Count == 0) ? 0 : s2.Pop();
				d3 = d1 + d2 + carryBit;
				if (d3 > 9)
				{
					d3 -= 10;
					carryBit = 1;
				}
				else
				{
					carryBit = 0;
				}
				if (!((i == maxLen) && (d3 == 0)))
				{
					n3 = d3.ToString() + n3;
				}
			}
			return new BigInt(n3);
		}

		public static BigInt operator ++(BigInt b1)
		{
			return b1 + BigInt.One();
		}
	}


	//class BigInt
	//{

	//    private uint[] digits;


	//    public int Length { get { return digits.Length; } }

	//    public BigInt(string num1)
	//    {
	//        digits = new uint[num1.Length];
	//        int n=0;
	//        foreach(char num in num1.ToCharArray())
	//        {
	//            digits[n++] = uint.Parse(num.ToString());
	//        }
	//    }

	//    private Stack<uint> ToIntStack()
	//    {
	//        Stack<uint> result = new Stack<uint>();
	//        foreach (uint d in digits)
	//        {
	//            result.Push(d);
	//        }
	//        return result;
	//    }

	//    public static BigInt Zero()
	//    {
	//        return new BigInt("0");
	//    }

	//    public static BigInt One()
	//    {
	//        return new BigInt("1");
	//    }

	//    public override string ToString()
	//    {
	//        StringBuilder s = new StringBuilder();
	//        foreach (uint d in digits)
	//        {
	//            s.Append(d);
	//        }
	//        return s.ToString();
	//    }

	//    public static BigInt operator +(BigInt b1, BigInt b2)
	//    {
	//        int maxLen = 1 + Math.Max(b1.Length, b2.Length);
	//        Stack<uint> s1 = b1.ToIntStack();
	//        Stack<uint> s2 = b2.ToIntStack();
	//        string n3 = "";
	//        uint carryBit = 0;
	//        uint d1 = 0;
	//        uint d2 = 0;
	//        uint d3 = 0;
	//        for (int n = 1; n <= maxLen; n++)
	//        {
	//            d1 = (s1.Count == 0) ? 0 : s1.Pop();
	//            d2 = (s2.Count == 0) ? 0 : s2.Pop();
	//            d3 = d1 + d2 + carryBit;

	//            if (d3 > 9)
	//            {
	//                d3 -= 10;
	//                carryBit = 1;
	//            }
	//            else
	//            {
	//                carryBit = 0;
	//            }
	//            if (!((n == maxLen) && (d3 == 0)))
	//            {
	//                n3 = d3 + n3;
	//            }
	//        }
	//        return new BigInt(n3);
	//    }

	//    public static BigInt operator ++(BigInt b1)
	//    {
	//        return b1 + One();
	//    }
	//}
}
