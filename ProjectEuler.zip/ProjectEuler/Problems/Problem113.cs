using System;
using ProjectEuler.Helpers;

namespace ProjectEuler.Problems
{
	class Problem113
	{

		// Working from left-to-right if no digit is exceeded by the digit to its left it is called an increasing num1; for example, 134468.

		// Similarly if no digit is exceeded by the digit to its right it is called d decreasing num1; for example, 66420.

		// We shall call d positive integer that is neither increasing nor decreasing d "bouncy" num1; for example, 155349.

		// As n increases, the proportion of bouncy numbers below n increases such that there are only 12951 numbers below 
		// one-million that are not bouncy and only 277032 non-bouncy numbers below 10^10.

		// How many numbers below d googol (10^100) are not bouncy?
		// "10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"

		public static void Solve(BigInteger maxCount)
		{
			BigInteger num = BigInteger.One;
			//int[] numAsc = new int[10];
			//int[] numDsc = new int[10];

			do
			{
				num++;
			} while (num.LengthNum < maxCount);



			//int numNotBouncy = 0;
			//int num = 1;
			//double percent;
			//do
			//{

			//    if (!MiscFunctions.IsBouncy(num))
			//    {
			//        numNotBouncy++;
			//    }
			//    percent = MiscFunctions.GetPercent(numNotBouncy, num); // because we started with 0!

			//    num++;


			//} while (percent < percentToHit);

			//num--;

			Console.WriteLine("We went to {1}", maxCount, num);
		}
	}
}
