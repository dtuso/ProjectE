using System;

using ProjectEuler.Helpers;

namespace ProjectEuler.Problems
{
    class Problem025
    {

        public static void Solve()
        {
            int maxIterations = 1000;
            int lastLen = 0;
            BigInt lastFactorial = BigInt.Zero();
            BigInt thisFactorial = BigInt.One();
            int i = 1;
            while (lastLen < maxIterations)
            {
                i++;
                thisFactorial = GetNextFactorial(thisFactorial, ref lastFactorial);
                if (thisFactorial.Length > lastLen)
                {
                    lastLen = thisFactorial.Length;
                    Console.WriteLine("F{0}={1} \t\t {2} long", i, thisFactorial, lastLen);
                }
            }
        }

        
        static BigInt GetNextFactorial(BigInt thisFactorial, ref BigInt lastFactorial)
        {
            BigInt tmp = thisFactorial;
            BigInt result = thisFactorial + lastFactorial;
            lastFactorial = tmp;
            return result;
        }

    }
}
